alert("js is working");
let weapons = ["sword", "axe", "shield"];

// Get the list element from HTML
let list = document.getElementById("weapon-list");

// Loop through each weapon and add to list
weapons.forEach((weapon) => {
  let li = document.createElement("li"); // make <li>
  li.textContent = weapon;               // set text to weapon
  list.appendChild(li);                  // add it to <ul>
});
 
  
  
  