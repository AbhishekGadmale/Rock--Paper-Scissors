
let click= document.querySelector("#click");
click.onclick= ()=> {
  console.log("hotay re bhai");
  let input=prompt("what you want to convert?");
if (input==="rupees"){
  let rupee = prompt("enter a how many dollars into rupee");
let rupees= 85.59;
console.log("converted Dollars: " + rupee*rupees);
}
else if(input==="dollars"){
 let dollar= prompt("convert Indian to dollar");
let dollars=1;
console.log("Converted Rupees: " + dollar/85.59);
}
else if(input==="euro") {
  let euro= prompt("convert euro into ruppe");
let euros= euro*99.81;
console.log("euro to rupees : " + euros);
}
else{
  console.log("select a valid currency");
}
};

let b1nmode=document.querySelector("#btnmode");
let currmode="light";
btnmode.addEventListener("click",() => {
  if(currmode==="light") {
    currmode="dark";
    document.querySelector("body").style.backgroundColor="black";
    document.querySelector("div").style.color="white";
  }
  else{
    currmode="light";
    document.querySelector("body").style.backgroundColor="white";
    document.querySelector("div").style.color="black";
  }
  console.log(currmode);
});




